/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Admin;

/**
 *
 * @author Administrator
 */
public interface GymInterface {
    
    void Table(String table);
    
    void viewDeletedTable(String table);
    
    void add();
    
    void edit();
    
    void softDelete(int Id);
    
    void restore(int Id);
    
}
